# DSA Assignment 2 – C++ Programs

Compile each program separately using:

```bash
g++ -std=c++17 -Wall -Wextra filename.cpp -o program
```

Run on Linux/macOS:
```bash
./program
```

Run on Windows:
```bash
program.exe
```

## Files
- Q1: Call by value, reference, pointer, and output prediction.
- Q2: Return by reference.
- Q3: Default arguments and function overloading.
- Q4: Savings account and transaction array.
- Q5A: Static Token output prediction.
- Q5B: Bus ticket static members and array of objects.
- Q6: Friend functions for time comparison.
- Q7: Circular buffer redesign demonstration.

Run each file separately and capture your own compiler/output screenshots.
